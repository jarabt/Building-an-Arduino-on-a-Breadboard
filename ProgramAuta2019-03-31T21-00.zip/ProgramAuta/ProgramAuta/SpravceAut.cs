﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ProgramAuta
{

    public class SpravceAut
    {
        public ObservableCollection<Auto> Auta { get; set; }
        public ObservableCollection<PolozkaVysledku> Vysledky { get; set; }

        List<Auto> autaZakladni;
        List<AutaDleModelu> autaDleModelu;


        public void Nacti()
        {
            // Configure open file dialog box
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".xml"; // Default file extension
            dlg.Filter = "Xml documents (.xml)|*.xml"; // Filter files by extension

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;

                var auta = XDocument.Load(filename);

                autaZakladni = auta.Root.Descendants("auto")
                    .Select(p => new Auto
                    {
                        Model = p.Attribute("model").Value,
                        Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                        Cena = Convert.ToDouble(p.Element("cena").Value),
                        DPH = Convert.ToDouble(p.Element("dph").Value),
                    }).ToList();

                autaDleModelu = auta.Root.Descendants("auto")
                .GroupBy(p => p.Attribute("model").Value)
                .Select(p => new AutaDleModelu
                {
                    Model = p.Key,
                    AutaDleKazdehoModelu = (p.Select(x => new AutoDle
                    {
                        Prodano = Convert.ToDateTime(x.Element("prodano").Value),
                        Cena = Convert.ToDouble(x.Element("cena").Value),
                        DPH = Convert.ToDouble(x.Element("dph").Value),
                    })).ToList()
                }).ToList();

                Auta = new ObservableCollection<Auto>(autaZakladni);
            }
        }

        public void Vypocti()
        {
            int i = 0;

            List<PolozkaVysledku> vysledkyList = new List<PolozkaVysledku>();

            foreach (var item in autaDleModelu)
            {

                vysledkyList.Add(new PolozkaVysledku { Model = item.Model,  CenaCelkem = 0.0, CenaCelkemDPH = 0.0 });

                
                foreach (var pro in item.AutaDleKazdehoModelu)
                {
                    if ((pro.Prodano.DayOfWeek == DayOfWeek.Saturday) || (pro.Prodano.DayOfWeek == DayOfWeek.Sunday))  //pro.Prodano, pro.Cena, pro.DPH);
                    {
                        vysledkyList[i].CenaCelkem += pro.Cena;
                        vysledkyList[i].CenaCelkemDPH += (pro.Cena + pro.Cena * (pro.DPH / 100));
                    }

                }
                
                ++i;
                

            }


            Vysledky = new ObservableCollection<PolozkaVysledku>(vysledkyList);

                
        }
      
    }

        
}
