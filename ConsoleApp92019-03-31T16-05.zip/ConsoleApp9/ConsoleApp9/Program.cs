﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp9
{
    

  


    // viz níže jsou třídy pro základní tabuklu
    public class AutoZ
    {
        public string Model { get; set; }
        public DateTime Prodano { get; set; }
        public double Cena { get; set; }
        public double DPH { get; set; }
    }

    // viz níže jsou třídy pro setříděná data: Auto, AutaDleModelu
    public class Auto
    {
        public DateTime Prodano { get; set; }
        public double Cena { get; set; }
        public double DPH { get; set; }
    }
    public class AutaDleModelu
    {
        public string Model { get; set; }
        public List<Auto> AutaDleKazdehoModelu { get; set; }


    }

    public class Polozka
    {
        public string Model { get; set; }
        public double CenaCelkem { get; set; }
        public double CenaCelkemDPH { get; set; }
    }






    class Program
    {
        static void Main(string[] args)
        {

            int i = 0;

            string s;


            List<Polozka> Vystup = new List<Polozka>();

           

            var auta = XDocument.Load("auta.xml");

            List<AutoZ> autaZakladni = auta.Root.Descendants("auto")
                .Select(p => new AutoZ
                {
                    Model = p.Attribute("model").Value,
                    Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                    Cena = Convert.ToDouble(p.Element("cena").Value),
                    DPH = Convert.ToDouble(p.Element("dph").Value),
                }).ToList();


            List<AutaDleModelu> autaDleModeluMS = auta.Root.Descendants("auto")
                .GroupBy(p => p.Attribute("model").Value)
                .Select(p => new AutaDleModelu
                {
                    Model = p.Key,
                    AutaDleKazdehoModelu = (p.Select(x => new Auto
                    {
                        Prodano = Convert.ToDateTime(x.Element("prodano").Value),
                        Cena = Convert.ToDouble(x.Element("cena").Value),
                        DPH = Convert.ToDouble(x.Element("dph").Value),
                    })).ToList()
                }).ToList();


            List<AutaDleModelu> autaDleModeluQS = (from p in auta.Root.Descendants("auto")
                                                   group p by p.Attribute("model").Value into g
                                                   select new AutaDleModelu
                                                   {
                                                       Model = g.Key,
                                                       AutaDleKazdehoModelu = (from x in g
                                                                               select new Auto
                                                                               {
                                                                                   Prodano = Convert.ToDateTime(x.Element("prodano").Value),
                                                                                   Cena = Convert.ToDouble(x.Element("cena").Value),
                                                                                   DPH = Convert.ToDouble(x.Element("dph").Value),
                                                                               }).ToList()
                                                   }).ToList();




            

            //var pokus = from j in autaZakladni
            //            where (j.Cena > 100000)
            //            select j;

            // výpis výsledku

            foreach (var item in autaDleModeluMS)
            {

                Vystup.Add(new Polozka { Model = item.Model, CenaCelkem = 0.0, CenaCelkemDPH = 0.0 });
                foreach (var pro in item.AutaDleKazdehoModelu)
                {
                    if ((pro.Prodano.DayOfWeek == DayOfWeek.Saturday) || (pro.Prodano.DayOfWeek == DayOfWeek.Sunday))  //pro.Prodano, pro.Cena, pro.DPH);
                    { 
                        Vystup[i].CenaCelkem += pro.Cena;
                        Vystup[i].CenaCelkemDPH += (pro.Cena + pro.Cena * (pro.DPH / 100));
                    }

                }

                ++i;


            }


            


            foreach (Polozka jmeno in Vystup)
            {
                Console.WriteLine("Model: {0}, Cena: {1}, Cena s DPH: {2}", jmeno.Model, jmeno.CenaCelkem, jmeno.CenaCelkemDPH);
            }


            Console.ReadKey();






            /*
          // konzole 




            // Polozka pokus = new Polozka { Model = "Mahesh Chand", CenaCelkem =  0, CenaCelkemDPH =  0 };

            // Vystup.Add(new Polozka { Model = "Mahesh Chand", CenaCelkem = 0, CenaCelkemDPH = 0 });




            foreach (AutoZ jmeno in pokus)
            {
                
                Vystup.Add(new Polozka { Model = jmeno.Model, CenaCelkem = 0, CenaCelkemDPH = 0 });
            }





            var pokus = from j in autaZakladni
                        where (j.Cena > 100000)
                        select j;

            // výpis výsledku
            foreach (AutoZ jmeno in pokus)
            {
                
                Vystup.Add(new Polozka { Model = jmeno.Model, CenaCelkem = 0, CenaCelkemDPH = 0 });
            }


            foreach (Polozka jmeno in Vystup)
            {
                Console.WriteLine("Model: {0}, Cena: {1}, Cena s DPH: {2}", jmeno.Model, jmeno.CenaCelkem, jmeno.CenaCelkemDPH);
            }


            Console.ReadKey();






            var pokus = from j in autaZakladni
                        where (j.Cena > 100000)
                        select j;

            // výpis výsledku
            foreach (AutoZ jmeno in pokus)
            {
                Console.WriteLine(jmeno.Model);
            }
            Console.ReadKey();










            string[] jmena = { "David", "Martin", "Dan", "Petr", "Vratislav", "Eliska" };

            var dotaz = from j in jmena
                        where (j.Length > 5)
                        select j;

            // výpis výsledku
            foreach (string jmeno in dotaz)
            {
                Console.WriteLine(jmeno);
            }
            Console.ReadKey();










            foreach (var item in autaZakladni)
            {
                Console.WriteLine("Model: {0}, Prodano: {1}, Cena: {2}, DPH: {3}",
                     item.Model, item.Prodano, item.Cena, item.DPH);
            }


            // konzole pro serazeny seznam viz níže

            foreach (var item in autaDleModeluMS)
            {
                Console.WriteLine("Model: {0}", item.Model);
                foreach (var pro in item.AutaDleKazdehoModelu)
                {
                    Console.WriteLine("Prodano: {0}, Cena: {1}, DPH: {2}",
                    pro.Prodano, pro.Cena, pro.DPH);
                }
                Console.WriteLine("-------------------------------------------------------");


            }


             foreach (var item in autaZakladni)
            {
                if (item.Model == "Škoda Oktávia")
                    i++;
                Console.WriteLine("i je {0}", i);
            }




            Console.WriteLine("Press enter to close...");
            Console.ReadLine();
            */
        }
    }
}
