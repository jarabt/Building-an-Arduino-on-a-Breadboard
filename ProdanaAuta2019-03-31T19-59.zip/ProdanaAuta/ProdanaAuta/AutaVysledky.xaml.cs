﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ProdanaAuta
{
    /// <summary>
    /// Interakční logika pro AutaVysledky.xaml
    /// </summary>
    public partial class AutaVysledky : Page
    {


        public ObservableCollection<PolozkaVysledku> Vysledky { get; set; }

        public AutaVysledky()
        {
            InitializeComponent();
            VysledkyDataGrid.ItemsSource = Vysledky;
        }

        public AutaVysledky(ObservableCollection<PolozkaVysledku> data)
        {
            // Bind to expense report data.
            Vysledky = data;
            InitializeComponent();
            VysledkyDataGrid.ItemsSource = Vysledky;
        }



    }
}


/*
 * public ExpenseReportPage()
        {
            InitializeComponent();
        }

        // Custom constructor to pass expense report data
        public ExpenseReportPage(object data) : this()
        {
            // Bind to expense report data.
            this.DataContext = data;
        }
*/