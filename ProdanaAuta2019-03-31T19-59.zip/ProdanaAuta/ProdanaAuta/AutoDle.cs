﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdanaAuta
{
    // viz níže jsou třída pro základní tabuklu
    public class AutoDle
    {
        
        public DateTime Prodano { get; set; }
        public double Cena { get; set; }
        public double DPH { get; set; }
    }
}

