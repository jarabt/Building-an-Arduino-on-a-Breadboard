﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramAuta
{

    // třída pro výpočet listu, který třídí auta podle modelu 
    public class AutaDleModelu
    {
        public string Model { get; set; }
        public List<AutoDle> AutaDleKazdehoModelu { get; set; }

    }
}
