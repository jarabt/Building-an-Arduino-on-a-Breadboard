﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ProdanaAuta
{

    public class SpravceAut
    {
        public ObservableCollection<Auto> Auta { get; set; }
        public ObservableCollection<PolozkaVysledku> Vysledky { get; set; }

        List<Auto> autaZakladni;
        PolozkaVysledku Oktavia;
        PolozkaVysledku Felicia;
        PolozkaVysledku Fabia;
        PolozkaVysledku Forman;
        PolozkaVysledku Favorit;

        public SpravceAut()
        {
            Oktavia = new PolozkaVysledku("Škoda Oktávia");
            Felicia = new PolozkaVysledku("Škoda Felicia");
            Fabia = new PolozkaVysledku("Škoda Fabia");
            Forman = new PolozkaVysledku("Škoda Forman");
            Favorit = new PolozkaVysledku("Škoda Favorit");
        }


        public void Nacti()
        {
            // Configure open file dialog box
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".xml"; // Default file extension
            dlg.Filter = "Xml documents (.xml)|*.xml"; // Filter files by extension

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;

                var auta = XDocument.Load(filename);

                autaZakladni = auta.Root.Descendants("auto")
                    .Select(p => new Auto
                    {
                        Model = p.Attribute("model").Value,
                        Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                        Cena = Convert.ToDouble(p.Element("cena").Value),
                        DPH = Convert.ToDouble(p.Element("dph").Value),
                    }).ToList();

                Auta = new ObservableCollection<Auto>(autaZakladni);
            }
        }

        public void Vypocti()
        {

            foreach (var item in autaZakladni)
                {
                    if ((item.Prodano.DayOfWeek == DayOfWeek.Saturday) || (item.Prodano.DayOfWeek == DayOfWeek.Sunday))
                    {

                        if (item.Model == "Škoda Oktávia")
                        {
                            Oktavia.CenaSuma += item.Cena;
                            Oktavia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                        }
                        else if (item.Model == "Škoda Felicia")
                        {
                            Felicia.CenaSuma += item.Cena;
                            Felicia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                        }
                        else if (item.Model == "Škoda Fabia")
                        {
                            Fabia.CenaSuma += item.Cena;
                            Fabia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                        }
                        else if (item.Model == "Škoda Forman")
                        {
                            Forman.CenaSuma += item.Cena;
                            Forman.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                        }
                        else if (item.Model == "Škoda Favorit")
                        {
                            Favorit.CenaSuma += item.Cena;
                            Favorit.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                        }
                    }

                }


                Vysledky = new ObservableCollection<PolozkaVysledku>();

                Vysledky.Add(Oktavia);
                Vysledky.Add(Felicia);
                Vysledky.Add(Fabia);
                Vysledky.Add(Forman);
                Vysledky.Add(Favorit);
        }
        




    }

        /*
        public void Vypocti()
        {
            foreach (var item in autaZakladni)
            {
                if ((item.Prodano.DayOfWeek == DayOfWeek.Saturday) || (item.Prodano.DayOfWeek == DayOfWeek.Sunday))
                {

                    if (item.Model == "Škoda Oktávia")
                    {
                        Oktavia.CenaSuma += item.Cena;
                        Oktavia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                    }
                    else if (item.Model == "Škoda Felicia")
                    {
                        Felicia.CenaSuma += item.Cena;
                        Felicia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                    }
                    else if (item.Model == "Škoda Fabia")
                    {
                        Fabia.CenaSuma += item.Cena;
                        Fabia.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                    }
                    else if (item.Model == "Škoda Forman")
                    {
                        Forman.CenaSuma += item.Cena;
                        Forman.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                    }
                    else if (item.Model == "Škoda Favorit")
                    {
                        Favorit.CenaSuma += item.Cena;
                        Favorit.CenaSumaDPH += (item.Cena + item.Cena * (item.DPH / 100));
                    }
                }

            }


            Vysledky = new ObservableCollection<PolozkaVysledku>();

            Vysledky.Add(Oktavia);
            Vysledky.Add(Felicia);
            Vysledky.Add(Fabia);
            Vysledky.Add(Forman);
            Vysledky.Add(Favorit);
        }
        */
    

}
