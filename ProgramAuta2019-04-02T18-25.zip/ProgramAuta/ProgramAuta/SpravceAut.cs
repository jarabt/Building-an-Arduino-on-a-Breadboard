﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Xml.Linq;

namespace ProgramAuta
{

    // logika programu

    public class SpravceAut
    {
        public ObservableCollection<Auto> Auta { get; set; }                    // kolekce pro zobrazení základní tabulky 
        public ObservableCollection<PolozkaVysledku> Vysledky { get; set; }     // kolekce pro zobrazení výsledků

        List<Auto> autaZakladni;                            // list zobrazení základní tabulky 
        List<AutaDleModelu> autaDleModelu;                  // list pro setřídění aut podle modelu, který souží jako podklad pro výpočet listu pro zobrazení výsledků

        public void Nacti()
        {
            // nastavení dialogu pro otevření souboru
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // přednastavené jméno souboru
            dlg.DefaultExt = ".xml"; // přednastavená přípona souboru
            dlg.Filter = "Xml documents (.xml)|*.xml"; // filter soubotů podle přípony

            // ukaž dialogové okno pro otevření souboru
            Nullable<bool> result = dlg.ShowDialog();

            // výsledek dialogového okna pro otevření souborů
            if (result == true)
            {
                
                // otevření dokumentu
                string filename = dlg.FileName;

                // Vyjímka pro úspěšné načtení správného dokumentu 
                try
                {                    
                    XDocument.Load(filename);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Chyba - načtěte prosím .xml soubor.", MessageBoxButton.OK, MessageBoxImage.Exclamation);
                    return;
                }

                var auta = XDocument.Load(filename);
                
                
                // převod xml souboru do listu pro zobrazení základní tabulky
                autaZakladni = auta.Root.Descendants("auto")
                    .Select(p => new Auto
                    {
                        Model = p.Attribute("model").Value,
                        Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                        Cena = Convert.ToDouble(p.Element("cena").Value),
                        DPH = Convert.ToDouble(p.Element("dph").Value),
                    }).ToList();                  
                
                // převod xml souboru do listu, který bude soužit jako podklad pro výpočet listu pro zobrazení výsledků (setřídí auta dle modelu)
                autaDleModelu = auta.Root.Descendants("auto")
                .GroupBy(p => p.Attribute("model").Value)
                .Select(p => new AutaDleModelu
                {
                    Model = p.Key,
                    AutaDleKazdehoModelu = (p.Select(x => new AutoDle
                    {
                        Prodano = Convert.ToDateTime(x.Element("prodano").Value),
                        Cena = Convert.ToDouble(x.Element("cena").Value),
                        DPH = Convert.ToDouble(x.Element("dph").Value),
                    })).ToList()
                }).ToList();

                // převod listu do kolekce, která slouží jako zdroj pro zobrazení základní tabulky
                Auta = new ObservableCollection<Auto>(autaZakladni);
            }
        }

        public void Vypocti()
        {
            int i = 0;

            List<PolozkaVysledku> vysledkyList = new List<PolozkaVysledku>();          //  list, který bude soužit jako podklad pro kolekci pro zobrazení výsledků 


            // naplnění listu, který bude soužit jako podklad pro zobrazení výsledků
            foreach (var item in autaDleModelu)
            {

                vysledkyList.Add(new PolozkaVysledku { Model = item.Model,  CenaCelkem = 0.0, CenaCelkemDPH = 0.0 });
                
                foreach (var pro in item.AutaDleKazdehoModelu)
                {
                    if ((pro.Prodano.DayOfWeek == DayOfWeek.Saturday) || (pro.Prodano.DayOfWeek == DayOfWeek.Sunday))  // podmínka prodeje o víkendu
                    {
                        vysledkyList[i].CenaCelkem += pro.Cena;
                        vysledkyList[i].CenaCelkemDPH += (pro.Cena + pro.Cena * (pro.DPH / 100));
                    }
                }
                
                ++i;         

            }

            // vytvoření kolekce pro zobrazení výsledků
            Vysledky = new ObservableCollection<PolozkaVysledku>(vysledkyList);                
        }
      
    }
        
}
