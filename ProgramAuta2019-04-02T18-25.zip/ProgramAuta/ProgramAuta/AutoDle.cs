﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramAuta
{
    // třída pro výpočet listu, který třídí auta podle modelu 
    public class AutoDle
    {        
        public DateTime Prodano { get; set; }
        public double Cena { get; set; }
        public double DPH { get; set; }
    }
}

