﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProdanaAuta
{
    // viz níže jsou třída pro základní tabuklu
    public class PolozkaVysledku
    {
        public string Model { get; set; }
        public double CenaSuma { get; set; }
        public double CenaSumaDPH { get; set; }

        public PolozkaVysledku(string m)
        {
            Model = m;
        }
    }
}

