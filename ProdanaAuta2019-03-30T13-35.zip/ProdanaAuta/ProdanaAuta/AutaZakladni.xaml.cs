﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace ProdanaAuta
{
    /// <summary>
    /// Interakční logika pro AutaZakladni.xaml
    /// </summary>
    public partial class AutaZakladni : Page
    {
        public AutaZakladni()
        {
            

            InitializeComponent();
                            // Nastavení zdroje dat pro tabulku

            }



        private void Nacti_Click(object sender, RoutedEventArgs e)
        {
            // Configure open file dialog box
            Microsoft.Win32.OpenFileDialog dlg = new Microsoft.Win32.OpenFileDialog();
            dlg.FileName = "Document"; // Default file name
            dlg.DefaultExt = ".xml"; // Default file extension
            dlg.Filter = "Xml documents (.xml)|*.xml"; // Filter files by extension

            // Show open file dialog box
            Nullable<bool> result = dlg.ShowDialog();

            // Process open file dialog box results
            if (result == true)
            {
                // Open document
                string filename = dlg.FileName;

                var auta = XDocument.Load(filename);

                List<AutoZ> autaZakladni = auta.Root.Descendants("auto")
                    .Select(p => new AutoZ
                    {
                        Model = p.Attribute("model").Value,
                        Prodano = Convert.ToDateTime(p.Element("prodano").Value),
                        Cena = Convert.ToDouble(p.Element("cena").Value),
                        DPH = Convert.ToDouble(p.Element("dph").Value),
                    }).ToList();

                ObservableCollection<AutoZ> myCollection = new ObservableCollection<AutoZ>(autaZakladni);

                InitializeComponent();
                AutaDataGrid.ItemsSource = myCollection;
            }
        }
    }
}
