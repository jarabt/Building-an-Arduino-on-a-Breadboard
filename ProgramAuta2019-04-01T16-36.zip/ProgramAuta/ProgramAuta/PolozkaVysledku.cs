﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgramAuta
{
    
    public class PolozkaVysledku
    {
        public string Model { get; set; }
        public double CenaCelkem { get; set; }
        public double CenaCelkemDPH { get; set; }
    }
}

